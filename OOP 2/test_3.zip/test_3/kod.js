class Osoba {
    constructor(ime, godina) {
        this._ime = ime;
        this._godinaRodenja = godina;
        this.adresa = "Zagreb 10000";
    }

    get ime() {
        return this._ime;
    }

    set ime(s) {
        if (s == "") {
            this._ime = "nepoznat";
        }
        else {
            this._ime = s;
        }
    }

    get godinaRodenja() {
        return this._godinaRodenja;
    }

    set godinaRodenja(v) {
        if (v < 0){
            this._godinaRodenja = 2022;
        }
        else {
            this._godinaRodenja = v;
        }
    }

    ispis() {
        console.log(this.constructor.name + ", " + this.ime + ", " + this.godinaRodenja + ", " + this.adresa);
    }
}

class Grad {
    constructor() {
        throw new Error("Ne može se instancirati");
    }

    static naziv = "Split";
    static posta = 21000;
}

class Radnik extends Osoba {
    constructor(ime, godina, adresa) {
        super(ime,godina);
        this.adresa = Grad.naziv + " " + Grad.posta.toString();
        this.placa = 0;
    }

    get godinaRodenja() {
        return this._godinaRodenja;
    }

    set godinaRodenja(v) {
        let a = 2022 - v;
        if (a < 18) {
            this._godinaRodenja = 0;
            this._ime = "neispravno";
        }
        else {
            this._godinaRodenja = v;
        }
    }

    isplata(sth) {
        switch (typeof(sth)) {
            case "string":
                if (sth == "minimalna") {
                this.placa = 3750;
                }
                break;
            case "number":
                this.placa = sth;
            default:
                break;
        }
    }
}