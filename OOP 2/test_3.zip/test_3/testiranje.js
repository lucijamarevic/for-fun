let Lucija = new Osoba("Lucija", 2001);
Lucija.ispis();
/*Lucija.godinaRodenja = -2;
Lucija.ispis();
Lucija.ime = "";
Lucija.ispis();*/ 

// zasad sve radi

let Petra = new Radnik("Petra", 2003, "Solin 21000");
Petra.ispis();
/*Petra.godinaRodenja = 2007;
Petra.ispis();*/

// takoder radi

let a = Petra.isplata("minimalna");
console.log(Petra.placa + "  //pokusaj s minimalna");
let b = Petra.isplata(2450);
console.log(Petra.placa + "  //pokusasj s 2450");