let a = new Auto();
let b = new Auto();

a.marka = "Ford";
a.brzina = 5;

b.marka = "Fiat";
b.brzina = -20;

while (true) {
  if (!a.idi()) {
    console.log(a.marka);
    console.log(a.razlika(b));
    break;
  }

  if (!b.idi()) {
    console.log(b.marka);
    console.log(b.razlika(a));
    break;
  }
}