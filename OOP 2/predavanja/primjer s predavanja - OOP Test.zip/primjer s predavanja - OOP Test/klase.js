class Auto {

  constructor() {
    this.marka = "";
    this._brzina = 0;
    this.startx = 0;
  }

  get brzina() {
    return this._brzina;
  }

  set brzina(b) {
    if (b < 0) {
      this._brzina = 2;
    }
    else {
      this._brzina = b;
    }
  }

  idi() {
    this.startx += this.brzina;

    if (this.startx >= 500) {
      return false;
    }
    else {
      return true;
    }
    
  }

  razlika(drugi) {
    let r = Math.abs(this.startx - drugi.startx);
    return r;
  }

}

