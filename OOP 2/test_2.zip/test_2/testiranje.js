let koza = new Animal(15,800);
koza.ispis();
/*koza.koraci = 805;
koza.ispis();
koza.koraci = -3;
koza.ispis();
koza.status = "";
koza.ispis();
koza.status = "trci";
koza.ispis();*/

// ovaj prvi dio je radia normalno

/*let i;
for (i = 0; i < 10; i++) {
    koza.povecaj();
}
koza.ispis();*/

// ne radi metoda povecaj

let cat = new Cat(20);
cat.ispis();

let dog = new Dog(30,200);
dog.ispis();

n = 10;

let i;
for (i = 0; i < n; i++) {
    koza.povecaj();
    cat.povecaj();
    dog.povecaj();
}

koza.ispis();
cat.ispis();
dog.ispis();   // ne radi metoda povecaj pa automatski ni nista od ovoga

koza.koraci = 600;
koza.ispis;
cat.koraci = 95;
cat.ispis;
dog.koraci = 205;
dog.ispis;