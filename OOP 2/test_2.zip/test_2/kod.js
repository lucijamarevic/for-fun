class Animal {
    constructor(k,g) {
        this._koraci = k;
        this._status = "start";
        this.granica = g;
    }

    get koraci() {
        return this._koraci;
    }

    set koraci(v) {
        if (v < 0) {
            this._koraci = 0;
            this.status = "hoda";
        }
        else if (v > this.granica) {
            this.status = "kraj";
        }
    }

    get status() {
        return this._status;
    }

    set status(st) {
        if (st != "") {
            this._status = st;
        }
    }

    ispis() {
        console.log(this.constructor.name + ", " + this.koraci + ", " + this.granica + ", " + this.status);
    }

    povecaj() {   // ovo ne radi, neman pojma zasto
        this.koraci ++; 
    }
}

class Cat extends Animal {
    constructor(k) {
        super(k,100);
    }

    povecaj() {
        this.koraci += 5;
    }
}

class Dog extends Animal {
    constructor(k,g) {
        super(k,g);
    }

    get koraci() {
        return this._koraci;
    }

    set koraci(v) {
        if (v < 0) {
            this._koraci = 0;
            this.status = "hoda";
        }
        else if (v > this.granica) {
            this.status = "kraj";
            this._koraci = this.granica;
        }
    }

    povecaj() {
        this.koraci += 15;
    }
}